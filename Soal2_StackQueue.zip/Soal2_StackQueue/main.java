/*
 * RAHMA SETIANINGSIH // 2902791371
 *
 * Tugas Personal Ke-2, Week 7 - Data Structure and Algorithm
 * Topik: Stack dan Queue
 */

import java.util.Scanner;

// Class Node digunakan untuk menyimpan data pelanggan
class Node {
    String nomorAntrian;    // Menyimpan nomor antrian pelanggan
    String namaPelanggan;   // Menyimpan nama pelanggan
    double totalBelanja;    // Menyimpan total belanja pelanggan
    Node next;              // Menunjuk ke node berikutnya

    // Constructor untuk membuat node pelanggan baru
    Node(String nomorAntrian, String namaPelanggan, double totalBelanja) {
        this.nomorAntrian = nomorAntrian;
        this.namaPelanggan = namaPelanggan;
        this.totalBelanja = totalBelanja;
        this.next = null;
    }
}

// Class Queue digunakan untuk mengelola antrian pelanggan
class Queue {
    Node front;             // Menunjuk ke pelanggan paling depan
    Node rear;              // Menunjuk ke pelanggan paling belakang
    int jumlahData = 0;     // Menyimpan jumlah pelanggan dalam antrian
    final int MAX_DATA = 5; // Batas maksimal pelanggan dalam antrian

    // Method khusus untuk menambahkan data awal tanpa menampilkan pesan
    public void tambahDataAwal(String nomorAntrian, String namaPelanggan, double totalBelanja) {
        // Jika jumlah pelanggan sudah mencapai batas maksimal, data tidak ditambahkan
        if (jumlahData >= MAX_DATA) {
            return;
        }

        // Membuat node pelanggan baru
        Node newNode = new Node(nomorAntrian, namaPelanggan, totalBelanja);

        // Jika antrian masih kosong, front dan rear menunjuk ke node baru
        if (rear == null) {
            front = rear = newNode;
        } else {
            // Jika antrian sudah berisi data, node baru ditambahkan ke belakang antrian
            rear.next = newNode;
            rear = newNode;
        }

        // Menambah jumlah pelanggan dalam antrian
        jumlahData++;
    }

    // Method enqueue untuk menambahkan pelanggan baru ke antrian
    public void enqueue(String nomorAntrian, String namaPelanggan, double totalBelanja) {
        // Validasi agar jumlah pelanggan tidak lebih dari 5
        if (jumlahData >= MAX_DATA) {
            System.out.println("Antrian penuh. Maksimal 5 pelanggan.");
            return;
        }

        // Membuat node pelanggan baru
        Node newNode = new Node(nomorAntrian, namaPelanggan, totalBelanja);

        // Jika antrian masih kosong, front dan rear menunjuk ke node baru
        if (rear == null) {
            front = rear = newNode;
        } else {
            // Jika antrian tidak kosong, node baru ditambahkan di belakang antrian
            rear.next = newNode;
            rear = newNode;
        }

        // Jumlah pelanggan bertambah
        jumlahData++;

        // Menampilkan pesan berhasil
        System.out.println("Data pelanggan ditambahkan ke antrian!");
    }

    // Method dequeue untuk melayani pelanggan paling depan
    public Node dequeue() {
        // Jika antrian kosong, tidak ada pelanggan yang bisa dilayani
        if (front == null) {
            System.out.println("Antrian kosong. Tidak ada pelanggan untuk dilayani.");
            return null;
        }

        // Menyimpan data pelanggan yang akan dilayani
        Node pelangganDilayani = front;

        // Front dipindahkan ke node berikutnya
        front = front.next;

        // Jika setelah dequeue antrian menjadi kosong, rear juga dibuat null
        if (front == null) {
            rear = null;
        }

        // Memutus hubungan node pelanggan yang sudah dilayani dari queue
        pelangganDilayani.next = null;

        // Mengurangi jumlah pelanggan dalam antrian
        jumlahData--;

        // Mengembalikan data pelanggan yang telah dilayani
        return pelangganDilayani;
    }

    // Method untuk menampilkan antrian pelanggan saat ini
    public void displayQueue() {
        // Jika antrian kosong, tampilkan pesan
        if (front == null) {
            System.out.println("Antrian kosong.");
            return;
        }

        // Traversal dimulai dari front
        Node current = front;

        // Nomor urut tampilan
        int nomor = 1;

        // Header tabel
        System.out.println("\nAntrian Pelanggan Saat Ini:");
        System.out.println("----------------------------------------------------------------------------");
        System.out.printf("%-5s | %-10s | %-25s | %-15s%n", "No", "Nomor", "Nama Pelanggan", "Total Belanja");
        System.out.println("----------------------------------------------------------------------------");

        // Menampilkan seluruh pelanggan dalam antrian
        while (current != null) {
            // Mengubah totalBelanja menjadi format Rupiah sederhana
            String totalFormat = "Rp " + String.format("%,.0f", current.totalBelanja).replace(",", ".");

            System.out.printf("%-5d | %-10s | %-25s | %-15s%n",
                    nomor,
                    current.nomorAntrian,
                    current.namaPelanggan,
                    totalFormat);

            // Pindah ke node berikutnya
            current = current.next;

            // Nomor urut bertambah
            nomor++;
        }

        // Footer tabel
        System.out.println("----------------------------------------------------------------------------");
        System.out.println("Total Antrian: " + jumlahData);
    }
}

// Class Stack digunakan untuk menyimpan riwayat transaksi
class Stack {
    Node top; // Menunjuk ke transaksi paling atas atau terbaru

    // Method push untuk menyimpan transaksi terbaru ke stack
    public void push(Node dataPelanggan) {
        // Membuat node baru dari data pelanggan yang selesai dilayani
        Node newNode = new Node(
                dataPelanggan.nomorAntrian,
                dataPelanggan.namaPelanggan,
                dataPelanggan.totalBelanja
        );

        // Node baru menunjuk ke top lama
        newNode.next = top;

        // Top diperbarui menjadi node baru
        top = newNode;
    }

    // Method untuk menampilkan riwayat transaksi dari terbaru ke lama
    public void displayStack() {
        // Jika stack kosong, tampilkan pesan
        if (top == null) {
            System.out.println("Riwayat transaksi masih kosong.");
            return;
        }

        // Traversal dimulai dari top
        Node current = top;

        // Nomor urut tampilan
        int nomor = 1;

        // Header tabel
        System.out.println("\nRiwayat Transaksi:");
        System.out.println("----------------------------------------------------------------------------");
        System.out.printf("%-5s | %-10s | %-25s | %-15s%n", "No", "Nomor", "Nama Pelanggan", "Total Belanja");
        System.out.println("----------------------------------------------------------------------------");

        // Menampilkan seluruh riwayat transaksi dari terbaru ke lama
        while (current != null) {
            // Mengubah totalBelanja menjadi format Rupiah sederhana
            String totalFormat = "Rp " + String.format("%,.0f", current.totalBelanja).replace(",", ".");

            System.out.printf("%-5d | %-10s | %-25s | %-15s%n",
                    nomor,
                    current.nomorAntrian,
                    current.namaPelanggan,
                    totalFormat);

            // Pindah ke transaksi berikutnya
            current = current.next;

            // Nomor urut bertambah
            nomor++;
        }

        // Footer tabel
        System.out.println("----------------------------------------------------------------------------");
    }
}

// Class utama program
public class main {
    public static void main(String[] args) {
        // Scanner digunakan untuk menerima input dari pengguna
        Scanner input = new Scanner(System.in);

        // Membuat objek Queue untuk antrian pelanggan
        Queue antrian = new Queue();

        // Membuat objek Stack untuk riwayat transaksi
        Stack riwayat = new Stack();

        // Menambahkan 3 data awal pelanggan ke dalam antrian
        antrian.tambahDataAwal("A001", "Andi", 125000);
        antrian.tambahDataAwal("A002", "Budi", 98000);
        antrian.tambahDataAwal("A003", "Citra", 150000);

        // Variabel untuk menyimpan pilihan menu
        int pilihan;

        // Perulangan menu sampai pengguna memilih keluar
        do {
            System.out.println("\n=== SISTEM KASIR TOKO ===");
            System.out.println("1. Tambah Antrian");
            System.out.println("2. Layani Pelanggan");
            System.out.println("3. Tampilkan Antrian");
            System.out.println("4. Lihat Riwayat Transaksi");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");

            // Membaca pilihan menu
            pilihan = input.nextInt();

            // Membersihkan enter setelah input angka
            input.nextLine();

            // Menjalankan menu berdasarkan pilihan pengguna
            switch (pilihan) {
                case 1:
                    // Input nomor antrian
                    System.out.print("Masukkan Nomor Antrian: ");
                    String nomorAntrian = input.nextLine();

                    // Input nama pelanggan
                    System.out.print("Masukkan Nama Pelanggan: ");
                    String namaPelanggan = input.nextLine();

                    // Input total belanja
                    System.out.print("Masukkan Total Belanja: ");
                    double totalBelanja = input.nextDouble();

                    // Membersihkan enter setelah input angka
                    input.nextLine();

                    // Menambahkan pelanggan ke queue
                    antrian.enqueue(nomorAntrian, namaPelanggan, totalBelanja);
                    break;

                case 2:
                    // Melayani pelanggan paling depan dengan dequeue
                    Node pelangganDilayani = antrian.dequeue();

                    // Jika ada pelanggan yang berhasil dilayani
                    if (pelangganDilayani != null) {
                        System.out.println("\nMelayani pelanggan "
                                + pelangganDilayani.nomorAntrian
                                + " (" + pelangganDilayani.namaPelanggan + ")");

                        // Menyimpan transaksi ke stack sebagai riwayat
                        riwayat.push(pelangganDilayani);

                        // Menampilkan pesan berhasil
                        System.out.println("Transaksi disimpan ke riwayat.");
                    }
                    break;

                case 3:
                    // Menampilkan antrian pelanggan saat ini
                    antrian.displayQueue();
                    break;

                case 4:
                    // Menampilkan riwayat transaksi dari terbaru ke lama
                    riwayat.displayStack();
                    break;

                case 5:
                    // Keluar dari program
                    System.out.println("Program selesai.");
                    break;

                default:
                    // Jika pilihan tidak tersedia
                    System.out.println("Pilihan tidak valid.");
            }

        } while (pilihan != 5);

        // Menutup scanner
        input.close();
    }
}