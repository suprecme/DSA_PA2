/*
 * RAHMA SETIANINGSIH // 2902791371
 *
 * Tugas Personal Ke=2, Week 7 - Data Structure and Algorithm
 */

import java.util.Scanner;

// Class Node digunakan untuk menyimpan data satu buku
class Node {
    String kodeBuku; 
    String judul;   
    String penulis;   
    Node next;        // Menunjuk ke node berikutnya

    // Constructor untuk membuat node buku baru
    Node(String kodeBuku, String judul, String penulis) {
        this.kodeBuku = kodeBuku; // Mengisi kode buku
        this.judul = judul;       // Mengisi judul buku
        this.penulis = penulis;   // Mengisi penulis buku
        this.next = null;         // Node baru belum menunjuk ke node lain
    }
}

// Class LinkedList untuk mengelola daftar buku
class LinkedList {
    Node head;          // Head menunjuk ke data buku pertama
    int jumlahData = 0; // Menyimpan jumlah buku dalam linked list

    // Method untuk menambahkan buku di akhir daftar
    public void tambahBuku(String kodeBuku, String judul, String penulis) {
        // Membuat node baru dari input buku
        Node newNode = new Node(kodeBuku, judul, penulis);

        // Jika linked list masih kosong, node baru menjadi head
        if (head == null) {
            head = newNode;
        } else {
            // Jika linked list tidak kosong, mulai traversal dari head
            Node current = head;

            // Menelusuri list sampai node terakhir
            while (current.next != null) {
                current = current.next;
            }

            // Node terakhir menunjuk ke node baru
            current.next = newNode;
        }

        // Jumlah data bertambah setelah buku berhasil ditambahkan
        jumlahData++;

        // Menampilkan pesan berhasil
        System.out.println("Data berhasil ditambahkan!");
    }

    // Method khusus untuk menambahkan data awal tanpa menampilkan pesan
    public void tambahDataAwal(String kodeBuku, String judul, String penulis) {
        // Membuat node baru untuk data awal
        Node newNode = new Node(kodeBuku, judul, penulis);

        // Jika list masih kosong, node baru menjadi head
        if (head == null) {
            head = newNode;
        } else {
            // Jika list sudah berisi data, traversal sampai node terakhir
            Node current = head;

            // Loop untuk mencari node terakhir
            while (current.next != null) {
                current = current.next;
            }

            // Node terakhir dihubungkan ke node baru
            current.next = newNode;
        }

        // Menambah jumlah data
        jumlahData++;
    }

    // Method untuk menghapus buku terakhir dari daftar
    public void hapusBukuTerakhir() {
        // Jika linked list kosong, tidak ada data yang bisa dihapus
        if (head == null) {
            System.out.println("Tidak ada data untuk dihapus.");
            return;
        }

        // Jika hanya ada satu buku dalam linked list
        if (head.next == null) {
            System.out.println("\nBuku yang dihapus:");
            System.out.println("Kode    : " + head.kodeBuku);
            System.out.println("Judul   : " + head.judul);
            System.out.println("Penulis : " + head.penulis);

            // Head dibuat null karena data sudah dihapus
            head = null;

            // Jumlah data dikurangi
            jumlahData--;

            return;
        }

        // Jika data lebih dari satu, mulai traversal dari head
        Node current = head;

        // Mencari node sebelum node terakhir
        while (current.next.next != null) {
            current = current.next;
        }

        // Menampilkan detail buku terakhir yang akan dihapus
        System.out.println("\nBuku yang dihapus:");
        System.out.println("Kode    : " + current.next.kodeBuku);
        System.out.println("Judul   : " + current.next.judul);
        System.out.println("Penulis : " + current.next.penulis);

        // Menghapus node terakhir dengan memutus pointer next
        current.next = null;

        // Jumlah data dikurangi
        jumlahData--;
    }

    // Method untuk mencari buku berdasarkan kode buku
    public void cariBuku(String kodeBuku) {
        // Mulai pencarian dari head
        Node current = head;

        // Traversal selama current tidak null
        while (current != null) {
            // Membandingkan kode buku tanpa memperhatikan huruf besar/kecil
            if (current.kodeBuku.equalsIgnoreCase(kodeBuku)) {
                System.out.println("\nBuku ditemukan:");
                System.out.println("Kode    : " + current.kodeBuku);
                System.out.println("Judul   : " + current.judul);
                System.out.println("Penulis : " + current.penulis);
                return;
            }

            // Pindah ke node berikutnya
            current = current.next;
        }

        // Jika loop selesai dan data tidak ditemukan
        System.out.println("Buku tidak ditemukan.");
    }

    // Method untuk menampilkan seluruh data buku dengan format tabel
    public void tampilkanSemuaBuku() {
        // Jika linked list kosong, tampilkan pesan
        if (head == null) {
            System.out.println("Daftar buku masih kosong.");
            return;
        }

        // Mulai traversal dari head
        Node current = head;

        // Nomor urut buku
        int nomor = 1;

        // Header tabel
        System.out.println("\nDaftar Buku:");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.printf("%-5s | %-8s | %-35s | %-25s%n", "No", "Kode", "Judul", "Penulis");
        System.out.println("--------------------------------------------------------------------------------");

        // Menampilkan setiap node dalam bentuk baris tabel
        while (current != null) {
            System.out.printf("%-5d | %-8s | %-35s | %-25s%n",
                    nomor,
                    current.kodeBuku,
                    current.judul,
                    current.penulis);

            // Pindah ke node berikutnya
            current = current.next;

            // Nomor urut bertambah
            nomor++;
        }

        // Footer tabel
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Total Buku: " + jumlahData);
    }
}

// Class utama program
public class main {
    public static void main(String[] args) {
        // Scanner digunakan untuk menerima input dari user
        Scanner input = new Scanner(System.in);

        // Membuat objek linked list untuk daftar buku
        LinkedList daftarBuku = new LinkedList();

        // Menambahkan 5 data awal dari 3 kategori buku: Self-Help, Novel, dan Komik
        daftarBuku.tambahDataAwal("SH001", "Atomic Habits", "James Clear");
        daftarBuku.tambahDataAwal("SH002", "The Mountain Is You", "Brianna Wiest");
        daftarBuku.tambahDataAwal("NV001", "Laskar Pelangi", "Andrea Hirata");
        daftarBuku.tambahDataAwal("NV002", "Bumi", "Tere Liye");
        daftarBuku.tambahDataAwal("CM001", "Doraemon", "Fujiko F. Fujio");

        // Variabel untuk menyimpan pilihan menu
        int pilihan;

        // Perulangan menu berjalan sampai user memilih keluar
        do {
            System.out.println("\n===== SISTEM DATA BUKU =====");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Hapus Buku");
            System.out.println("3. Cari Buku");
            System.out.println("4. Lihat Semua Buku");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");

            // Membaca pilihan menu
            pilihan = input.nextInt();

            // Membersihkan newline setelah input angka
            input.nextLine();

            // Menjalankan menu berdasarkan pilihan user
            switch (pilihan) {
                case 1:
                    // Input kode buku
                    System.out.print("Masukkan Kode Buku: ");
                    String kodeBuku = input.nextLine();

                    // Validasi kode buku maksimal 5 karakter
                    if (kodeBuku.length() > 5) {
                        System.out.println("Kode buku maksimal 5 karakter.");
                        break;
                    }

                    // Input judul buku
                    System.out.print("Masukkan Judul: ");
                    String judul = input.nextLine();

                    // Input nama penulis
                    System.out.print("Masukkan Penulis: ");
                    String penulis = input.nextLine();

                    // Menambahkan buku ke linked list
                    daftarBuku.tambahBuku(kodeBuku, judul, penulis);
                    break;

                case 2:
                    // Menghapus buku terakhir
                    daftarBuku.hapusBukuTerakhir();
                    break;

                case 3:
                    // Input kode buku yang ingin dicari
                    System.out.print("Masukkan Kode Buku yang dicari: ");
                    String kodeCari = input.nextLine();

                    // Mencari buku berdasarkan kode
                    daftarBuku.cariBuku(kodeCari);
                    break;

                case 4:
                    // Menampilkan seluruh daftar buku
                    daftarBuku.tampilkanSemuaBuku();
                    break;

                case 5:
                    // Keluar dari program
                    System.out.println("Program selesai.");
                    break;

                default:
                    // Jika user memasukkan menu yang tidak tersedia
                    System.out.println("Pilihan tidak valid.");
            }

        } while (pilihan != 5);

        // Menutup scanner
        input.close();
    }
}